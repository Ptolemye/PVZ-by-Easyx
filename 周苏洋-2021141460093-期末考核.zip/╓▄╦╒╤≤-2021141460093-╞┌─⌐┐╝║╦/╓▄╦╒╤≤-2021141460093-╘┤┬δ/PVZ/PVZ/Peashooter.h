#pragma once
#ifndef PEASHOOTER_H
#define PEASHOOTER_H
#include"Plant.h"
class Peashooter:public Plant {
private:
	IMAGE im_peashooter[12];
	IMAGE to_plant;
public:
	DWORD shoot_t1;
	DWORD shoot_t2;
	int shoot_step = 1;
	bool is_shooting = false;
	bool reload_over = false;
	Peashooter(int row, int col) :Plant(row, col) {
		type = 2;
		HP = 200;
		draw_step = 1;
		cold_count = 5;
		cold_time = 5;
		ready_to_plant = true;
		cost = 100;
		draw_t1 = GetTickCount();
		shoot_t1 = GetTickCount();
	}
	//����ͼ��
	void Set_image() {
		TCHAR filename[80];
		for (int i = 1; i < 9; i++)
		{
			_stprintf_s(filename, _T("image\\Peashooter\\image%d.png"), i);
			loadimage(&im_peashooter[i], filename);
		}
		loadimage(&im_peashooter[9], _T("image\\Peashooter\\shoot1.png"));
		loadimage(&im_peashooter[10], _T("image\\Peashooter\\shoot2.png"));
		_stprintf_s(filename, _T("image\\Peashooter\\to_plant.png"));
		loadimage(&to_plant, filename);
	}
	//����Ч��
	void draw() {
		draw_t2 = GetTickCount();
		putimagePng(start_x + col * LENGTH, start_y + row * WIDTH, &im_peashooter[draw_step]);
		//������ʱ
		if (draw_t2 - draw_t1 > 200) {
			draw_step++;
			draw_t1 = draw_t2;
		}
		if (draw_step == 9&&!is_shooting)draw_step = 1;
		if (draw_step == 11) {
			draw_step = 1;
			reload_over = true;
		}
	}
	void to_plant_draw() {
		putimagePng(start_x + col * LENGTH, start_y + row * WIDTH, &to_plant);
	}
};
#endif
